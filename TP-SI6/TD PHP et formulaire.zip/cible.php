<p><?php echo "Bonjour ".$_POST['Nom']." !"; ?></p>
<p>Le mot de passe est [<?php echo $_POST['MdP']; ?>] !</p>
<p>Pour recommencer la saisie, <a href="formulaire.php">cliquer ici</a>.</p>